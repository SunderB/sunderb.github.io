# jekyll-octicons

[![Gem version](https://img.shields.io/gem/v/jekyll-octicons.svg)](https://rubygems.org/gems/jekyll-octicons)

See https://primer.style/octicons/packages/jekyll