module Octicons
  VERSION = "14.2.2".freeze
end
