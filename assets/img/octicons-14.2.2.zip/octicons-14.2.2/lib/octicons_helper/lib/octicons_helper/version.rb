module OcticonsHelper
  VERSION = "14.2.2".freeze
end
