# @primer/octicons-react

[![npm version](https://img.shields.io/npm/v/@primer/octicons-react.svg)](https://www.npmjs.org/package/@primer/octicons-react)

See https://primer.style/octicons/packages/react